import './index.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Hero from './components/Hero'
import Login from './components/Login'
import Register from './components/Register'
import ProtectedRoute from './components/ProtectedRoute'
import { AuthProvider } from './context/AuthContext'
import Header from './components/Header'

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-black">
          <Routes>
            <Route path="/login" element={
              <>
                <Header />
                <Login />
              </>
            } />
            <Route path="/register" element={
              <>
                <Header />
                <Register />
              </>
            } />
            <Route path="/" element={
              <ProtectedRoute>
                <Hero />
              </ProtectedRoute>
            } />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  )
}

export default App
