import { useState } from 'react';
import { CalendarDays, Car, Hotel, MapPin, Plane, Squircle, Users } from 'lucide-react';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";

export default function SearchForm() {
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [travelers, setTravelers] = useState('2');
  const [activeTab, setActiveTab] = useState<'hotels' | 'flights' | 'cars'>('hotels');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log({
      destination,
      startDate,
      endDate,
      travelers,
      type: activeTab
    });
    // In a real application, you would handle the search here
    alert(`Searching for ${activeTab} in ${destination}`);
  };

  return (
    <div className="w-full max-w-4xl bg-white/10 backdrop-blur-md rounded-lg p-6 shadow-2xl">
      {/* Tab Navigation */}
      <div className="flex mb-6 border-b border-white/20">
        <button
          onClick={() => setActiveTab('hotels')}
          className={`flex items-center gap-2 px-4 py-2 ${
            activeTab === 'hotels' 
              ? 'text-yellow-400 border-b-2 border-yellow-400' 
              : 'text-white hover:text-yellow-200'
          }`}
        >
          <Hotel className="w-5 h-5" />
          <span>Hotels</span>
        </button>
        <button
          onClick={() => setActiveTab('flights')}
          className={`flex items-center gap-2 px-4 py-2 ${
            activeTab === 'flights' 
              ? 'text-yellow-400 border-b-2 border-yellow-400' 
              : 'text-white hover:text-yellow-200'
          }`}
        >
          <Plane className="w-5 h-5" />
          <span>Flights</span>
        </button>
        <button
          onClick={() => setActiveTab('cars')}
          className={`flex items-center gap-2 px-4 py-2 ${
            activeTab === 'cars' 
              ? 'text-yellow-400 border-b-2 border-yellow-400' 
              : 'text-white hover:text-yellow-200'
          }`}
        >
          <Car className="w-5 h-5" />
          <span>Cars</span>
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {/* Destination Input */}
          <div className="col-span-full md:col-span-1">
            <label htmlFor="destination" className="block text-white mb-2">Destination</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MapPin className="h-5 w-5 text-yellow-400" />
              </div>
              <input
                id="destination"
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white/20 backdrop-blur-md text-white border border-yellow-400/50 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                placeholder="Where are you going?"
                required
              />
            </div>
          </div>

          {/* Check-in Date */}
          <div>
            <label className="block text-white mb-2">Check-in</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                <CalendarDays className="h-5 w-5 text-yellow-400" />
              </div>
              <DatePicker
                selected={startDate}
                onChange={(date) => setStartDate(date)}
                selectsStart
                startDate={startDate}
                endDate={endDate}
                minDate={new Date()}
                placeholderText="Select date"
                className="w-full pl-10 pr-4 py-2 bg-white/20 backdrop-blur-md text-white border border-yellow-400/50 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                wrapperClassName="w-full"
                calendarClassName="bg-gray-900 border border-yellow-400/50 text-white"
                dateFormat="MMM d, yyyy"
              />
            </div>
          </div>

          {/* Check-out Date */}
          <div>
            <label className="block text-white mb-2">Check-out</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                <CalendarDays className="h-5 w-5 text-yellow-400" />
              </div>
              <DatePicker
                selected={endDate}
                onChange={(date) => setEndDate(date)}
                selectsEnd
                startDate={startDate}
                endDate={endDate}
                minDate={startDate || new Date()}
                placeholderText="Select date"
                className="w-full pl-10 pr-4 py-2 bg-white/20 backdrop-blur-md text-white border border-yellow-400/50 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                wrapperClassName="w-full"
                calendarClassName="bg-gray-900 border border-yellow-400/50 text-white"
                dateFormat="MMM d, yyyy"
              />
            </div>
          </div>

          {/* Travelers */}
          <div>
            <label htmlFor="travelers" className="block text-white mb-2">Travelers</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Users className="h-5 w-5 text-yellow-400" />
              </div>
              <select
                id="travelers"
                value={travelers}
                onChange={(e) => setTravelers(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white/20 backdrop-blur-md text-white border border-yellow-400/50 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent appearance-none"
              >
                <option value="1">1 Traveler</option>
                <option value="2">2 Travelers</option>
                <option value="3">3 Travelers</option>
                <option value="4">4 Travelers</option>
                <option value="5+">5+ Travelers</option>
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <svg className="w-4 h-4 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Search Button */}
        <button
          type="submit"
          className="w-full py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 text-black font-semibold rounded-lg hover:from-yellow-500 hover:to-yellow-600 transition-all duration-300"
        >
          {activeTab === 'hotels' ? 'Search Hotels' : activeTab === 'flights' ? 'Search Flights' : 'Search Cars'}
        </button>
      </form>

      {/* Travel Service Options */}
      <div className="mt-6 grid grid-cols-3 md:grid-cols-6 gap-4 text-white text-center">
        <div className="flex flex-col items-center gap-2 cursor-pointer hover:text-yellow-400">
          <Plane className="w-6 h-6" />
          <span>Flights</span>
        </div>
        <div className="flex flex-col items-center gap-2 cursor-pointer hover:text-yellow-400">
          <Hotel className="w-6 h-6" />
          <span>Hotels</span>
        </div>
        <div className="flex flex-col items-center gap-2 cursor-pointer hover:text-yellow-400">
          <Car className="w-6 h-6" />
          <span>Cars</span>
        </div>
        <div className="flex flex-col items-center gap-2 cursor-pointer hover:text-yellow-400">
          <Squircle className="w-6 h-6" />
          <span>Yachts</span>
        </div>
        <div className="flex flex-col items-center gap-2 cursor-pointer hover:text-yellow-400">
          <Plane className="w-6 h-6" />
          <span>Private Jets</span>
        </div>
        <div className="flex flex-col items-center gap-2 cursor-pointer hover:text-yellow-400">
          <Car className="w-6 h-6" />
          <span>Luxury Cars</span>
        </div>
      </div>
    </div>
  );
}
