import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X } from 'lucide-react';

export default function Concierge() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300"
      >
        <MessageCircle className="w-8 h-8 text-black" />
      </button>

      {/* Popup dialog */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed bottom-24 right-8 w-96 bg-white rounded-lg shadow-2xl"
          >
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-yellow-400 to-yellow-500 flex items-center justify-center">
                    <span className="text-black text-xl">🎩</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">Personal Concierge</h3>
                    <p className="text-sm text-gray-500">How can I assist you today?</p>
                  </div>
                </div>
                <button onClick={() => setIsOpen(false)}>
                  <X className="w-6 h-6 text-gray-500 hover:text-gray-700" />
                </button>
              </div>
            </div>
            <div className="p-4 h-80 overflow-y-auto">
              <div className="space-y-4">
                <p className="text-gray-700">
                  Welcome to Xperienxes Travel Group! I'm your personal concierge, ready to help you plan your perfect luxury getaway. What type of experience are you looking for?
                </p>
                {/* Add more chat interface elements here */}
              </div>
            </div>
            <div className="p-4 border-t">
              <input
                type="text"
                placeholder="Type your message..."
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
