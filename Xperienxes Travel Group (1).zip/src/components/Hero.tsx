import { useState } from 'react';
import SearchForm from './SearchForm';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import Header from './Header';
import Concierge from './Concierge';

export default function Hero() {
  const { user } = useAuth();

  return (
    <div className="relative min-h-screen">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url("https://images.unsplash.com/photo-1514282401047-d79a71a590e8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")'
        }}
      />

      {/* Header with logo and logout */}
      <Header />

      {/* Content */}
      <div className="relative z-10 h-[calc(100vh-80px)] flex flex-col items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-8"
        >
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-yellow-400 via-yellow-200 to-yellow-400 bg-clip-text text-transparent">
            Xperienxes Travel Group
          </h1>
          <p className="text-white text-xl md:text-2xl">
            Luxury Travel & Concierge Services
          </p>
        </motion.div>

        <SearchForm />
      </div>
      
      {/* Concierge component */}
      <Concierge />
    </div>
  );
}
