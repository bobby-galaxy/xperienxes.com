import { useAuth } from '../context/AuthContext';
import { LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="relative z-20 w-full">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <img 
            src="https://mocha-cdn.com/0194143e-a2a4-71fb-8bb6-397d4cfc5114/XPERIENXES--official-logo-new1.1.png" 
            alt="Xperienxes Travel Group" 
            className="h-12 md:h-16"
          />
        </Link>
        
        {user && (
          <div className="flex items-center gap-4">
            <span className="hidden md:inline text-white">Welcome, {user.name}</span>
            <button
              onClick={logout}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
            >
              <LogOut size={16} />
              <span className="hidden md:inline">Logout</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
